import React from 'react'
import './Banner.css'
const Banner = () => {
  return (
    <>
      <div className='hero-section'>
        <div className='hero-content'>SHADOW WORLD <br/> LEGENDS REALM</div>
        <div className='hero-content2'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Architecto<br/> odit suscipit odio voluptatibus beatae impedit,dignissimos provident? </div>
      </div>
    </>
  )
}

export default Banner
