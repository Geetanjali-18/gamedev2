import "./App.css"
import Navbar from './components/Navbar/Navbar'
import GamePage from "./components/GamePage/GamePage";
import GithubPage from "./components/GithubPage/GithubPage";
import GithubCard from "./components/cards/GithubCard";
function App() {
  return (
    <>
    {/* <Navbar></Navbar> */}
    <GithubPage></GithubPage>
    {/* <GithubCard></GithubCard> */}
    </>
  );
}
export default App;
